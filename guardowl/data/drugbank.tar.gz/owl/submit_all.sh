for i in */; do echo $i; qsub ../run_hydra.sh /data/cluster/projects/drugbank/data/${i}; sleep 1;  done
