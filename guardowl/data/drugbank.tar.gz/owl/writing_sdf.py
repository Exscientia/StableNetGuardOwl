# %%
from openbabel import pybel

# %%
for mol in pybel.readfile("sdf", "3D_structures.sdf"):
	filename = mol.OBMol.GetTitle()
	print(filename)
	base = f"{filename}/"
	filename = base + filename + ".sdf"
	output = open(filename,"w") # erase existing file, if any
	output.write(mol.write("sdf"))
	output.close()

# %%



